@extends('adminlte::page')  
@section('title', 'Form Penerbit')  
@section('content_header')
<h1>Input Data Penerbit</h1><br/>
<a class="btn btn-secondary btn-md" href="{{ '/buku' }}" role="button">Back</a><br/><br/>
<table class="table table-striped">
@stop  
@section('content')
{{-- Ini Konten Form Input Penerbit --}} 
{{-- Panggil master data buku, penerbit dan kategori untuk
ditampilkan di element form --}}
@php
$rs1 = App\Models\Buku::all();
$rs2 = App\Models\Pengarang::all();
$rs3 = App\Models\Kategori::all();
@endphp
<form method="POST" action="{{ route('pengarang.store') }}">
@csrf {{-- security untuk menghindari dari serangan pada saat input form --}}

<div class="form-group">
<label>Nama</label>
<input type="text" name="nama" class="form-control"/>
<label>Alamat</label>
<input type="text" name="alamat" class="form-control"/>
<label>Email</label>
<input type="text" name="email" class="form-control"/>
<label>Website</label>
<input type="text" name="Website" class="form-control"/>
<label>Hp</label>
<input type="text" name="hp" class="form-control"/>
<label>Cp</label>
<input type="text" name="cp" class="form-control"/>
</div>
{{-- Panggil master data pengarang untuk ditampilkan di element form select --}}



<button type="submit" class="btn btn-primary"
name="proses">Simpan</button>

<button type="reset" class="btn btn-warning"
name="unproses">Batal</button>

@stop
@section('css')
<link rel="stylesheet" href="/css/admin_custom.css">  
@stop
@section('js')
<script> console.log('Hi!'); </script>  
@stop