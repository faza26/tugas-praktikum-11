@extends('adminlte::page')  
@section('title', 'Edit Penerbit') 
@section('content_header')
    <h1>Edit Data Penerbit</h1>  
@stop  
@section('content')
{{-- Ini Konten Form Edit Penerbit --}}  
{{-- Panggil master data buku, penerbit dan kategori untuk
ditampilkan di element form edit Penerbit --}}

@foreach($data as $rs)
<form method="POST" action="{{ route('penerbit.update',$rs->id) }}">
@endforeach
@csrf {{-- security untuk menghindari dari serangan pada saat input form --}}
@method('put') {{-- method put digunakan untuk meletakkan data yang akan diubah
disetiap element form edit buku --}}
<div class="form-group">
<label>Nama</label>
<input type="text" name="nama" value="{{ $rs->nama }}" class="form-control"/>
<label>Alamat</label>
<input type="text" name="alamat" value="{{ $rs->alamat }}" class="form-control"/>
<label>Email</label>
<input type="text" name="email" value="{{ $rs->email }}" class="form-control"/>
<label>website</label>
<input type="text" name="website" value="{{ $rs->website }}" class="form-control"/>
<label>Hp</label>
<input type="text" name="telp" value="{{ $rs->telp }}" class="form-control"/>
<label>Cp</label>
<input type="text" name="cp" value="{{ $rs->cp }}" class="form-control"/>
</div>
<div class="form-group">

<div class="form-group">
    <button type="submit" class="btn btn-primary"><i class="fa fa-save mr-2"></i>Simpan</button>
    <button type="reset" class="btn btn-secondary"><i class="fa fa-undo mr-2"></i>Reset</button>
    <a href="{{ route('penerbit.index') }}" class="btn btn-danger"><i
    class="fa fa-times mr-2"></i>Batal</a>
</div>

@stop
@section('css')
<link rel="stylesheet" href="/css/admin_custom.css">
@stop
@section('js')
<script> console.log('Hi!'); </script>  
@stop